# angular-ivy-nx28my

[Edit on StackBlitz ⚡️](https://stackblitz.com/edit/jv-template-directives)